def add(in0, in1):
    in3 = in0 + in1
    
    return in3

def sub(in0, in1):
    in3 = in0 - in1
    
    return in3

def sel(ad, sb, select):
    if select ==0:
        res=ad
    
    else:
        res=sb
    
    return res


in1=1
in2=1
dw=1
s=0

ad = add(in1, dw)
sb = sub(in1, dw)
r = sel(ad, sb, s)

print(r)

