from polyphony import testbench

def add(in0, in1):
    in3 = in0 + in1
    
    return in3

def sub(in0, in1):
    in3 = in0 - in1
    
    return in3

def selector(ad, sb, select):
    if select ==0:
        res=ad
    
    else:
        res=sb
    
    return res
    

def addsub(in1, dw, sel):
    ad = add(in1, dw)
    sb = sub(in1, dw)
    r = selector(ad, sb, sel)
    
    return r

@testbench
def test():
    c=0
    
    
    result = addsub(1, 1, 0)
    print("count = ",c," result = ",result)
    c+=1
    result = addsub(1, 2, 0)
    print("count = ",c," result = ",result)
    c+=1
    result = addsub(2, 1, 0)
    print("count = ",c," result = ",result)
    c+=1
    result = addsub(1, 1, 1)
    print("count = ",c," result = ",result)
    c+=1
    result = addsub(2, 1, 1)
    print("count = ",c," result = ",result)
    c+=1
    result = addsub(3, 1, 1)
    print("count = ",c," result = ",result)
        

test()