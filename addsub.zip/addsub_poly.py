from polyphony import testbench

def add(in0, in1):
    in3 = in0 + in1
    
    return in3

def sub(in0, in1):
    in3 = in0 - in1
    
    return in3

def selector(ad, sb, select):
    if select == 0:
        res=ad
    
    elif select == 1:
        res=sb
    
    return res
    

def addsub(in1, dw, sel, count):
    ad = add(in1[count], dw[count])
    sb = sub(in1[count], dw[count])
    r = selector(ad, sb, sel[count])
    
    return r

@testbench
def test():
    c=0
    
    inx = [1,1,2,1,2,3]
    iny = [1,2,1,1,1,1]
    selc = [0,0,0,1,1,1]
    
    
    result = addsub(inx, iny, selc, c)
    print("in =",inx[c],"dw =",iny[c],"sel =",selc[c],"count =",c," result =",result)
    c+=1
    result = addsub(inx, iny, selc, c)
    print("in =",inx[c],"dw =",iny[c],"sel =",selc[c],"count =",c," result =",result)
    c+=1
    result = addsub(inx, iny, selc, c)
    print("in =",inx[c],"dw =",iny[c],"sel =",selc[c],"count =",c," result =",result)
    c+=1
    result = addsub(inx, iny, selc, c)
    print("in =",inx[c],"dw =",iny[c],"sel =",selc[c],"count =",c," result =",result)
    c+=1
    result = addsub(inx, iny, selc, c)
    print("in =",inx[c],"dw =",iny[c],"sel =",selc[c],"count =",c," result =",result)
    c+=1
    result = addsub(inx, iny, selc, c)
    print("in =",inx[c],"dw =",iny[c],"sel =",selc[c],"count =",c," result =",result)
        

test()